import UIKit
var greeting = "Hello, playground"

//Understanding strings
var 👸🏻="Rose"
print (👸🏻)

var 🤴🏻="Jack"
var Titanic = 👸🏻+"💖"+🤴🏻

//
